--[[
LuCI - Lua Configuration Interface

Copyright 2012 Michel Stempin <michel.stempin@wanadoo.fr>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id: $
]]--

module("luci.controller.admin.arduino", package.seeall)

function index()
   entry({"admin", "arduino"}, alias("admin", "arduino", "flash"), _("Arduino"), 50).index = true
   entry({"admin", "arduino", "flash"}, call("action_flash_arduino"), _("Flash Arduino"), 10)
   local page = entry({"admin", "arduino", "avrdude"}, call("avrdude"), nil)
   page.leaf = true
end

function action_flash_arduino()
   local sys = require "luci.sys"
   local fs  = require "luci.fs"
   local image_tmp   = "/tmp/Arduino_firmware.hex"

   local function image_supported()
      local result = true;
      for line in io.lines(image_tmp) do
         size, address, rectype, data = string.match (line, "^:(%x%x)(%x%x%x%x)(%x%x)(%x+)%s*$")
         if not size then
            result = false
         end
      end
      if tonumber(size) ~= 0 or tonumber(address) ~= 0 or tonumber(rectype) ~= 1 then
         result = false
      end
      return result
   end

   local function image_checksum()
      return (luci.sys.exec("md5sum %q" % image_tmp):match("^([^%s]+)"))
   end

   local fp
   luci.http.setfilehandler(
      function(meta, chunk, eof)
         if not fp then
            if meta and meta.name == "image" then
               fp = io.open(image_tmp, "w")
            end
         end
         if chunk then
            fp:write(chunk)
         end
         if eof then
            fp:close()
         end
      end
   )

   if luci.http.formvalue("image") or luci.http.formvalue("step") then
      --
      -- Confirm Arduino Firmware Flashing
      --
      local step = tonumber(luci.http.formvalue("step") or 1)
      local board_id = luci.http.formvalue("board")
      local boards = board_list()
      local board_name = boards[board_id]
      local tty = luci.http.formvalue("tty")
      if step == 1 then
         if image_supported() then
            luci.template.render("admin_arduino/confirm", {
                                    checksum = image_checksum(),
                                    size     = nixio.fs.stat(image_tmp).size,
                                    board_id = board_id,
                                    board_name = board_name,
                                    tty = tty
                                 })
         else
            nixio.fs.unlink(image_tmp)
            luci.template.render("admin_arduino/upload", {
                                    image_invalid = true
                                 })
         end
         --
         -- Start flashing Arduino Board
         --
      elseif step == 2 then
         luci.template.render("admin_arduino/flash", {
                                 title = luci.i18n.translate("Flashing..."),
                                 msg   = luci.i18n.translate("The system is flashing the Arduino board now.<br /><b>DO NOT POWER OFF THE SYSTEM!</b>."),
                                 board = board_id,
                                 tty = tty
                              })
      end
   else
      --
      -- Upload Arduino Firmware
      --
      luci.template.render("admin_arduino/upload", {
                              boards = board_list(),
                              ttys = tty_list()
                           })
   end
end

function avrdude()
   local path = luci.dispatcher.context.requestpath
   local image_tmp   = "/tmp/Arduino_firmware.hex"
   if #path == 6 then
      local board_id = path[4]
      local tty = "/" .. path[5] .. "/" .. path[6]
      if board_id and board_id:match("^[a-zA-Z0-9%-_]+$") and tty and tty:match("^/dev/tty[A-Z]+[0-9]+$") then
         local programmer, baudrate, partno = board_param(board_id)
         if programmer then
            luci.http.prepare_content("text/plain")
            local util = io.popen("echo 0 > /sys/class/gpio/gpio8/value; sleep 1; echo 1 > /sys/class/gpio/gpio8/value; sleep 1; /usr/bin/avrdude -C/etc/avrdude.conf -p%s -c%s -P%s -b%s -D -Uflash:w:%s:i 2>&1" %{ partno, programmer, tty, baudrate, image_tmp })
            if util then
               while true do
                  local ln = util:read("*l")
                  if not ln then break end
                  luci.http.write(ln)
                  luci.http.write("\n")
               end
               util:close()
            end
            return
         end
      end
   end
   luci.http.status(500, "Bad parameters")
end

function board_list()
   local uci = require("luci.model.uci")
   local boards = {}
   state = uci.cursor_state()
   state:set_confdir("/usr/share/arduino/hardware/arduino/")
   state:load("arduino")
   state:foreach("arduino", "boards",
                 function(section)
                    local ids = section.id
                    local names = section.name
                    for i = 1, #ids do
                       boards[ids[i]] = names[i]
                    end
                 end
              )
   state:unload("arduino")
   return boards
end

function board_param(board)
   local uci = require("luci.model.uci")
   local boards = {}
   state = uci.cursor_state()
   state:set_confdir("/usr/share/arduino/hardware/arduino/boards")
   state:load(board)
   local protocol = state:get_first(board, "upload", "protocol")
   local speed = state:get_first(board, "upload", "speed")
   local mcu = state:get_first(board, "build", "mcu")
   state:unload(board)
   return protocol, speed, mcu
end

function tty_list()
   local fs = require "nixio.fs"
   local ttys = {}
   local i = 1
   for tty in fs.glob("/dev/ttyACM[0-9]*") do
      ttys[i] = tty
      i = i + 1
   end
   for tty in fs.glob("/dev/ttyUSB[0-9]*") do
      ttys[i] = tty
      i = i + 1
   end
   return ttys
end
