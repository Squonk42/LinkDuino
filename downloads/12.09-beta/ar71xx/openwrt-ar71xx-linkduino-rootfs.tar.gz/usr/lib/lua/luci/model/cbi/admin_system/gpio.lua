--[[
LuCI - Lua Configuration Interface

Copyright 2012 Michel Stempin <michel.stempin@wanadoo.fr>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id: $
]]--

m = Map("gpio",
	translate("<abbr title=\"General Purpose Input/Output\">GPIO</abbr> Configuration"),
	translate("Customize the behavior of <abbr title=\"General Purpose Input/Output\">GPIO</abbr>s."))

local sysfs_path = "/sys/class/gpio/"
local gpios = {}

local fs   = require "nixio.fs"

for chip in fs.glob(sysfs_path .. "gpiochip[0-9]") do
  local base = tonumber(nixio.fs.readfile(chip .. "/base")) or 0
  local ngpio = tonumber(nixio.fs.readfile(chip .. "/ngpio")) or 1
  if ngpio - 1 > base then
    j = 1
    for i = base, ngpio - 1 do
      gpios[j] = i
      j = j + 1
    end
  end
end
table.sort(gpios)

s = m:section(TypedSection, "gpio", translate("<abbr title=\"General Purpose Input/Output\">GPIO</abbr>s"))
s.addremove = true
s.anonymous = true

s.template  = "cbi/tblsection"

name = s:option(Value, "name", translate("Name"))
name.datatype = "string"
name.rmempty = false

gpio = s:option(ListValue, "gpio", translate("<abbr title=\"General Purpose Input/Output\">GPIO</abbr>"))
gpio.datatype = "uinteger"
gpio.rmempty = true
for i, gpio_number in ipairs(gpios) do
  gpio:value(gpio_number)
end

direction = s:option(ListValue, "direction", translate("Direction"))
direction:value("in", translate("in"))
direction:value("out", translate("out"))
direction.datatype = "string"
direction.rmempty = true

active_low = s:option(Flag, "active_low", translate("Active Low"))
active_low.rmempty = false

init_value = s:option(ListValue, "value", translate("Init Value"))
init_value:value("0", "0")
init_value:value("1", "1")
init_value:depends("direction", "out")
init_value.datatype = "bool"
init_value.rmempty = true

current_value = s:option(DummyValue, "_current_value", translate("Current Value"))
current_value.template = "admin_system/gpio_status"

return m
